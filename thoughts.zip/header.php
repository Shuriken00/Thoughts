<?php session_start();

?>

<!doctype html>
<html>
     <head>
	     <meta charset="utf-8">
		 <meta name="description" content="Free And OpenSource Social Media That Cares About Privacy">
		 <meta name=viewport content="width=device-width, initial-scale=1">
         <link rel="stylesheet" type="text/css" href="styles/nav.css" media="screen" />
		 <title>Thoughts</title>

	 </head>
<body>

</body>
<header>
         <nav>
		   <a href="index.php">
		     <img src="img/logo.png" alt="logo">
			 </a>
			 <ul>
			     <li><a href="index.php">Home</a></li>
				 <li><a href="#">Profile</a></li>
				 <li><a href="#">Report a Problem</a></li>
				 <li><a href="#">TOS</a></li>
				 <li><a href="#">About</a></li>
                 </ul>
                 <div>

		 </nav>
</header>
<?php
require 'login.php';
 ?>
