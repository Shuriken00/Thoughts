<?php
require "header.php";

 ?>

 <main>
 <p> you are logged in </p> <br/>
<p> you are logged out </p>
 </main>
 <?php
require "footer.php";
 ?>
