<html>
<main>
<form action="includes/login.inc.php" method="POST">
<input type="text" name="Email" placeholder="username/email...">
<input type="password" name="Password" placeholder="Password...">
<button type="submit" name="login">Login</button>
</form>
<a href="signup.php">Signup</a>
<form action="includes/logout.inc.php" method="POST">
 <button type="submit" name="logout">Logout</button>
</main>
